# 特征提取

* preproc_2.py：处理黑名单，原始数据位于mytest文件夹

* preproc_white.py：处理白名单，原始数据位于whitelist文件夹
* 处理结果都写入static/feature.csv


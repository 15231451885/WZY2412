# 基于机器学习的Android恶意流量检测算法和系统
* collect 爬虫收集黑名单
* data_proc 特征提取
* flaskproject 服务器前端网页
